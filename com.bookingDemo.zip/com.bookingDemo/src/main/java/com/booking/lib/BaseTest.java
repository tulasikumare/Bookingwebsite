package com.booking.lib;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeSuite;



import io.appium.java_client.android.AndroidDriver;

public class BaseTest {
	public static Properties prop;
	public AndroidDriver driver;
	public static DesiredCapabilities cap;	
	@BeforeSuite()
	public void LaunchApp() throws MalformedURLException
	{
		try {
			prop=new Properties();
			FileInputStream fis=new FileInputStream(GenericLib.configPath);
			prop.load(fis);
			
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cap=new DesiredCapabilities();
		cap.setCapability(prop.getProperty("devicename"), prop.getProperty("devicenamevalue"));
		cap.setCapability(prop.getProperty("platformVersion"), prop.getProperty("platformVersionvalue"));
		cap.setCapability(prop.getProperty("platformName"), prop.getProperty("platformNamevalue"));
		cap.setCapability(prop.getProperty("automationName"), prop.getProperty("automationNamevalue"));
		cap.setCapability(prop.getProperty("appPackage"),prop.getProperty("appPackagevalue"));
		cap.setCapability(prop.getProperty("appActivity"),prop.getProperty("cappActivityvalue"));
		driver=new AndroidDriver(new URL(prop.getProperty("url")), cap);
	}

}
