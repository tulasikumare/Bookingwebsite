package com.booking.lib;

public class GenericLib {
public static String sDirPath=System.getProperty("user.dir");
	
	//public static String configPath=sDirPath + "\\src\\main\\resources\\Property\\config.properties";
    public static String configPath="D:\\Appium\\com.bookingDemo\\src\\main\\resourses\\config.properties";
	
	public static String appiumlog=sDirPath + "\\src\\main\\resources\\Property\\appiumlog.txt";

}
